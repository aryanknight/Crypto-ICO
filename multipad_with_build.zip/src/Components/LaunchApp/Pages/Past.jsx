import React from 'react';
import './Pages.css';
import Box from '../Box.jsx';

export default function Past() {
    return (
        <div className="past">
            <div style={{height: '100vh'}}>

</div>
        </div>
    )
}
