import React from 'react';
import Box from '../Box.jsx';
import './Pages.css';

export default function Ucoming() {
    return (
        <div className="upcoming">
            <Box/>
        </div>
    )
}
