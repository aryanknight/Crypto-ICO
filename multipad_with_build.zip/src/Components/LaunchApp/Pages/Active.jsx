import React from 'react';
import './Pages.css';
import Box from '../Box.jsx';

export default function Active() {
    return (
        <div className="active">
           <div style={{height: '100vh'}}>

           </div>
        </div>
    )
}
